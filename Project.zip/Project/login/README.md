# login-verification
Login Verification using Face Recognition

Checkout this Video for Reference (https://youtu.be/fccOCWJ5ZFU)
